<?php
session_start();
		//if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
		// last request was more than 30 minutes ago
		//session_unset();     // unset $_SESSION variable for the run-time 
		//session_destroy();   // destroy session data in storage
		//}
		//$_SESSION["level"]=$row["level"];
		//$_SESSION['LAST_ACTIVITY'] = time();
		$_SESSION['name'] = $_POST['name']
		$_SESSION['password'] = $_POST['password']
		

$servername = "166.62.27.60";
$username = "gfasia";
$password = "gfasia88";
$dbname = "userlist";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT level FROM userlist where username='" . $_POST['name'] . "' and password='". $_POST['password'] ."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "username: " . $row["username"]. " - userID: " . $row["userID"]. " " . $row["level"]. "<br>";
		
		
		if ($row["level"] == 1){
			header("Location: https://griffinasia.com/download1.html"); 
			exit;
		} elseif ($row["level"] == 2){
			header("Location: https://griffinasia.com/download2.html"); 
			exit;
		} elseif ($row["level"] == 3){
			header("Location: https://griffinasia.com/download3.html"); 
			exit;
		} else{
			header("Location: https://griffinasia.com/nopermission.html"); 
			exit;
		} 
    }
} else {
    echo "0 results";
}




$conn->close();
?>
<html>
<head>
	<title>Redirect Form</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

</head>
<body>

    <?php echo $_POST['name']; ?> 

        
</body> 
</html>