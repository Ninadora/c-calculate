

<?php
$servername = "166.62.27.60";
$username = "gfasia";
$password = "gfasia88";
try {
    $conn = new PDO("mysql:host=$servername;dbname=myDB", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
	
	
	echo $_GET["name"]; <br>
	echo $_GET["password"];
	
//$sql = "SELECT level FROM userlist where username='+$_GET["name"]+' and password='+$_GET["password"]+'";

$sql ="select * from userlist ";
$result = mysqli_query($conn, $sql);



//$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "level: " . $row["level"].  "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>