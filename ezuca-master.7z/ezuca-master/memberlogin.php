<?php
//$servername = "166.62.27.60";
//$servername = "localhost";
//$username = "gfasia";
//$password = "gfasia88";
//$con = mysql_connect('localhost','gfasia','gfasia88');
$con = mysql_connect('localhost','root','');
mysql_select_db('userlist', $con);
$query = "SELECT * FROM userlist";
$result = mysql_query($query);
if($result){
		while($row = mysql_fetch_array($result)){
			$name = $row["$username"];
			echo "Name: ".$name."<br/>";
			?>alert("yes");  <?php
		}
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Griffinest Asia Securities</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!-- ElegantFonts CSS -->
    <link rel="stylesheet" href="css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="css/swiper.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="hero-content">
        <header class="site-header">
            <div class="top-header-bar">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-lg-6 d-none d-md-flex flex-wrap justify-content-center justify-content-lg-start mb-3 mb-lg-0">
                            <div class="header-bar-email d-flex align-items-center">
                                <a href="#"><img src="images/logo-securities_en.gif" alt=""></a>
                            </div><!-- .header-bar-email -->

                            <div class="header-bar-text lg-flex align-items-center">
                                <p></p>
                            </div><!-- .header-bar-text -->
                        </div><!-- .col -->

                        <div class="col-12 col-lg-6 d-flex flex-wrap justify-content-center justify-content-lg-end align-items-center">
                            <div class="header-bar-search">
                                
                            </div><!-- .header-bar-search -->

                            <div class="header-bar-menu">
                               
                            </div><!-- .header-bar-menu -->
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .container-fluid -->
            </div><!-- .top-header-bar -->

            <div class="nav-bar">
                <div class="container">
                    <div class="row">
                        <div class="col-9 col-lg-3">
                            <div class="site-branding">
                                <h1 class="site-title"></h1>
                            </div><!-- .site-branding -->
                        </div><!-- .col -->

                        <div class="col-3 col-lg-9 flex justify-content-end align-content-center">
                            <nav class="site-navigation flex justify-content-end align-items-center">
                                <ul class="flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                   
                                    <li><a href="#">Recruit</a></li>
                                    <li><a href="#">Products</a></li>
                                    <li><a href="#">English</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>

                                <div class="hamburger-menu d-lg-none">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div><!-- .hamburger-menu -->

                                <div class="header-bar-cart">
                                    <a href="login.html"  onclick="openwin()"  value="openwin" class="flex justify-content-center align-items-center"><span aria-hidden="true" class="icon_bag_alt"></span></a>
                                </div><!-- .header-bar-search -->
                            </nav><!-- .site-navigation -->
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .nav-bar -->
        </header><!-- .site-header -->

        <div class="hero-content-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="hero-content-wrap flex flex-column justify-content-center align-items-start">
                            <header class="entry-header">
                                
                                <h1>Griffinest Asia Securities<br/>瑞豐亞洲證券</h1>
                            </header><!-- .entry-header -->

                            <div class="entry-content">
                                <p>Griffinest Asia Securities, LLC is a full service securities broker/dealer located in Pasadena, California. As a member of FINRA and SIPC, we provide personalized service and focused attention to assist you in your investment decisions. For a complete line of products and services visit our Products & Services page. Exercising our best care, we clear all trades through Pershing LLC, which provides an efficient and secure operating environment for all your orders. Our website also offers you the convenience of reviewing current market data, and accessing your account information through our internet based NetX Investor. It is convenient and informative. We appreciate your interest in our company and we thank you for choosing Griffinest Asia Securities, LLC.</p>
                            </div><!-- .entry-content -->

                            <footer class="entry-footer read-more">
                                
                            </footer><!-- .entry-footer -->
                        </div><!-- .hero-content-wrap -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .hero-content-hero-content-overlay -->
    </div><!-- .hero-content -->
	<section class="about-section">
        <div class="container">
            <div class="row">
                <div class=" align-content-lg-stretch">
                    <header class="heading">
                        <h2 class="entry-title">login</h2>

                        <p>
							
hi!

						</p>
					</header>
				</div>
			</div>                
		</div>
    </section>    
	
 
    <section class="about-section">
        <div class="container">
            <div class="row">
                <div class=" align-content-lg-stretch">
                    <header class="heading">
                        <h2 class="entry-title">Contact</h2>

                        <p>                     
                                Phone: 626-792-1388
                                Fax: 626-792-3380
                                Address: 3452 E. Foothill Blvd., Suite 100, Pasadena, CA, USA 91107
					</header>
				</div>
			</div>                
		</div>
    </section>         
                        
                       

    
        <p id="copyright" style="display:block; float: left; margin: 5px 0; font-size: 85%">Copyright © <script>document.write(new Date().getFullYear());</script> Griffinest Asia Securities. All rights reserved.
                  </p>                    

                    

                       

                        
                    
                    
                    
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .footer-widgets -->

        
    </footer><!-- .site-footer -->

<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/swiper.min.js'></script>
<script type='text/javascript' src='js/masonry.pkgd.min.js'></script>
<script type='text/javascript' src='js/jquery.collapsible.min.js'></script>
<script type='text/javascript' src='js/custom.js'></script>

</body>
</html>